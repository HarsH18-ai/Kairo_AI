#include <windows.h>
#include <string>

int main() {
    wchar_t exePath[MAX_PATH];
    DWORD length = GetModuleFileNameW(nullptr, exePath, MAX_PATH);
    if (length == 0 || length >= MAX_PATH) {
        return 1;
    }

    std::wstring exeDir = exePath;
    size_t slashPos = exeDir.find_last_of(L"\\/");
    if (slashPos == std::wstring::npos) {
        return 1;
    }

    exeDir = exeDir.substr(0, slashPos);
    std::wstring scriptPath = exeDir + L"\\brain.py";
    std::wstring args = L"\"" + scriptPath + L"\"";

    HINSTANCE result = ShellExecuteW(nullptr, L"open", L"pythonw.exe", args.c_str(), exeDir.c_str(), SW_HIDE);
    if (reinterpret_cast<INT_PTR>(result) <= 32) {
        result = ShellExecuteW(nullptr, L"open", L"python.exe", args.c_str(), exeDir.c_str(), SW_HIDE);
    }

    return (reinterpret_cast<INT_PTR>(result) <= 32) ? 1 : 0;
}