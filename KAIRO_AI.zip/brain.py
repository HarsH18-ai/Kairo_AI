import customtkinter as ctk
import datetime
import random
from google import genai
from google.genai import types

# Optional: Paste your Gemini API key inside the quotes below for unlimited AI chat
API_KEY = "YOUR_API_KEY"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class KairoApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("K.A.I.R.O — AI Friend")
        self.geometry("500x650")
        self.resizable(False, False)

        self.chat_session = None
        if API_KEY != "YOUR_API_KEY" and API_KEY.strip() != "":
            try:
                self.client = genai.Client(api_key=API_KEY)
                self.chat_session = self.client.chats.create(
                    model="gemini-2.5-flash",
                    config=types.GenerateContentConfig(
                        system_instruction=(
                            "You are Kairo, the user's close, supportive, and witty best friend. "
                            "Talk casually like a real friend. Keep replies short (1-3 sentences) "
                            "and give practical, fun suggestions when the user is bored or stressed."
                        )
                    )
                )
            except Exception as e:
                print("AI Init Error:", e)

        # Header Bar
        self.header = ctk.CTkFrame(self, height=60, corner_radius=0, fg_color="#1a1a2e")
        self.header.pack(fill="x")
        
        status_text = "●  K.A.I.R.O (AI Online)" if self.chat_session else "●  K.A.I.R.O (Friend Mode)"
        self.title_label = ctk.CTkLabel(
            self.header, text=status_text, 
            font=ctk.CTkFont(family="Segoe UI", size=18, weight="bold"),
            text_color="#00f5d4"
        )
        self.title_label.pack(pady=15, padx=20, anchor="w")

        # Scrollable Chat Area
        self.chat_area = ctk.CTkScrollableFrame(self, fg_color="#0f0f1a")
        self.chat_area.pack(fill="both", expand=True, padx=10, pady=10)

        # Quick Suggestion Buttons
        self.chips_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.chips_frame.pack(fill="x", padx=10, pady=(0, 5))

        suggestions = [
            ("I'm Bored", "I am bored, suggest something!"),
            ("Music Vibe", "Suggest some good music"),
            ("Stressed", "I am feeling stressed today"),
            ("Time", "What is the time?")
        ]
        for label, msg in suggestions:
            btn = ctk.CTkButton(
                self.chips_frame, text=label, height=28, width=105,
                corner_radius=14, fg_color="#252542", hover_color="#3b3b66",
                font=ctk.CTkFont(size=12),
                command=lambda m=msg: self.quick_send(m)
            )
            btn.pack(side="left", padx=4)

        # Bottom Input Bar
        self.input_frame = ctk.CTkFrame(self, height=60, fg_color="transparent")
        self.input_frame.pack(fill="x", padx=10, pady=(5, 12))

        self.entry = ctk.CTkEntry(
            self.input_frame, placeholder_text="Message Kairo...",
            height=45, corner_radius=22, font=ctk.CTkFont(size=14)
        )
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.entry.bind("<Return>", lambda event: self.send_message())

        self.send_btn = ctk.CTkButton(
            self.input_frame, text="Send", width=80, height=45,
            corner_radius=22, fg_color="#00bbf9", hover_color="#0096c7",
            font=ctk.CTkFont(size=14, weight="bold"),
            command=self.send_message
        )
        self.send_btn.pack(side="right")

        self.add_bubble("Kairo", "Hey bro! Kairo GUI is live. Click a button below or type a message!", is_user=False)

    def add_bubble(self, sender, text, is_user=True):
        bubble_color = "#0077b6" if is_user else "#22223b"
        align = "e" if is_user else "w"

        bubble = ctk.CTkLabel(
            self.chat_area, text=text, wraplength=340, justify="left",
            fg_color=bubble_color, text_color="white",
            corner_radius=16, padx=14, pady=10,
            font=ctk.CTkFont(family="Segoe UI", size=14)
        )
        bubble.pack(anchor=align, pady=6, padx=8)
        self.chat_area._parent_canvas.yview_moveto(1.0)

    def quick_send(self, text):
        self.entry.delete(0, "end")
        self.entry.insert(0, text)
        self.send_message()

    def get_reply(self, message):
        text = message.lower().strip()

        if self.chat_session:
            try:
                response = self.chat_session.send_message(message)
                return response.text.strip()
            except Exception as e:
                return f"AI Error: {e}"

        if any(w in text for w in ["hi", "hello", "hey", "yo"]):
            return random.choice([
                "Yo! How's your day going so far?",
                "Hey bro! Ready to build something cool or just chilling today?",
                "Hey there! Good to see you. What's the plan?"
            ])
        elif any(w in text for w in ["bored", "suggest", "idea"]):
            return random.choice([
                "Since you're free, how about picking up the guitar and playing a few chords for 15 minutes?",
                "Suggestion: Throw on some chill music, grab a coffee, and try a fun coding idea!",
                "Take a quick break from the screen—go for a short walk or watch an episode of a good series!"
            ])
        elif any(w in text for w in ["stressed", "tired", "busy", "exam"]):
            return random.choice([
                "Take a breather, man! Drink some water, stretch your back, and step away from the laptop for 10 minutes.",
                "Don't burn yourself out! Break your work into small 20-minute chunks and chill after."
            ])
        elif any(w in text for w in ["music", "song"]):
            return "Throw on an acoustic playlist—something like Anuv Jain or unplugged Hindi tracks sets the best mood!"
        elif "time" in text:
            return f"It's {datetime.datetime.now().strftime('%I:%M %p')} right now, bro!"
        elif "date" in text:
            return f"Today is {datetime.date.today().strftime('%B %d, %Y')}."
        else:
            return random.choice([
                "Haha, tell me more! Or click one of the quick buttons below if you want suggestions.",
                "I hear you, bro! What else is on your mind today?",
                "Got you! Ask me for music ideas or tell me if you're bored or stressed."
            ])

    def send_message(self):
        user_msg = self.entry.get().strip()
        if not user_msg:
            return

        self.entry.delete(0, "end")
        self.add_bubble("You", user_msg, is_user=True)

        reply = self.get_reply(user_msg)
        self.after(200, lambda: self.add_bubble("Kairo", reply, is_user=False))

if __name__ == "__main__":
    app = KairoApp()
    app.mainloop()